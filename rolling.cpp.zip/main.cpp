#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <thread>
using namespace std;

int main()
{
    srand(time(0));
    
    int die;
    
    cout << "Hello! this is a die rolling simlulator! please enter the amout of die you want to roll. 1-6." << endl;
    cin >> die;
    
    for(int i=0; i < die; i++) {
        cout << "Dice " << i+1 << ": " <<  (rand() % 6 + 1) << endl;
        this_thread::sleep_for(chrono::seconds(1));
    }

    return 0;
}